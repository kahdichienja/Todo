<?php

use Illuminate\Database\Eloquent\Model;
    class Stat extends Model{
        // protected $table = 'departments';
        protected $guarded = [];

        // public function comments (){
        //     return $this->hasMany(Comment::class);
        // }
    }